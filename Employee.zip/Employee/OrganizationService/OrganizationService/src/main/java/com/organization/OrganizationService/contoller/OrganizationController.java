package com.organization.OrganizationService.contoller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.organization.OrganizationService.entity.OrganizationEntity;
import com.organization.OrganizationService.exception.ResourceNotAvailableException;
import com.organization.OrganizationService.service.api.OrganizationService;

@Controller
public class OrganizationController {
	
	@Autowired
	private OrganizationService organizationService;
	
	@GetMapping("/organization/{orgid}")
	public ResponseEntity<OrganizationEntity> getOrganizationDetails(@PathVariable(value = "orgid") Long orgId) throws ResourceNotAvailableException{
		
		OrganizationEntity orgEntity = organizationService.getOrganizationDetails(orgId)
				.orElseThrow(() -> new ResourceNotAvailableException("Organization not found for this id :: " + orgId));
		
		return ResponseEntity.ok().body(orgEntity);
		
	}
	
    @RequestMapping(value = "/create/organization", method = RequestMethod.POST, produces = "application/json")
    public OrganizationEntity createOrganization(@RequestBody OrganizationEntity organization) {
        return organizationService.saveOrganization(organization);
    }

}
