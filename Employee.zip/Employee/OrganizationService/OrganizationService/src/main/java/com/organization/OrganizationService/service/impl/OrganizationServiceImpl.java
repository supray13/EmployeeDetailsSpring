package com.organization.OrganizationService.service.impl;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.organization.OrganizationService.dao.api.OrganizationDao;
import com.organization.OrganizationService.entity.OrganizationEntity;
import com.organization.OrganizationService.service.api.OrganizationService;

@Component
public class OrganizationServiceImpl implements OrganizationService {
	
	@Autowired
	private OrganizationDao orgDao;

	@Override
	public Optional<OrganizationEntity> getOrganizationDetails(long orgId) {
		
		return orgDao.findById(orgId);
	}

	@Override
	public OrganizationEntity saveOrganization(OrganizationEntity organization) {
		
		return orgDao.save(organization);
	}

}
