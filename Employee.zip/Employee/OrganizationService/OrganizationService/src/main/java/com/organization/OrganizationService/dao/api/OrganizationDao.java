package com.organization.OrganizationService.dao.api;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.organization.OrganizationService.entity.OrganizationEntity;

@Repository
public interface OrganizationDao extends JpaRepository<OrganizationEntity, Long>{

}
