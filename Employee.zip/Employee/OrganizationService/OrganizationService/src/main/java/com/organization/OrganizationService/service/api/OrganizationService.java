package com.organization.OrganizationService.service.api;

import java.util.Optional;

import org.springframework.stereotype.Service;

import com.organization.OrganizationService.entity.OrganizationEntity;

@Service
public interface OrganizationService {
	
	Optional<OrganizationEntity> getOrganizationDetails(long orgId);
	
	OrganizationEntity saveOrganization(OrganizationEntity organization);

}
