package com.organization.OrganizationService.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "ORGANIZATION")
public class OrganizationEntity implements Serializable{
	
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "ID", nullable = false)
	private long orgId;
	
	@Column(name = "NAME", nullable = false)
	private String orgName;
	
	@Column(name = "ADDRESS", nullable = false)
	private String orgAddress;

	public OrganizationEntity() {
		super();
	}

	public OrganizationEntity(long orgId, String orgName, String orgAddress) {
		super();
		this.orgId = orgId;
		this.orgName = orgName;
		this.orgAddress = orgAddress;
	}

	public long getOrgId() {
		return orgId;
	}

	public void setOrgId(long orgId) {
		this.orgId = orgId;
	}

	public String getOrgName() {
		return orgName;
	}

	public void setOrgName(String orgName) {
		this.orgName = orgName;
	}

	public String getOrgAddress() {
		return orgAddress;
	}

	public void setOrgAddress(String orgAddress) {
		this.orgAddress = orgAddress;
	}

	@Override
	public String toString() {
		return "OrganizationEnity [orgId=" + orgId + ", orgName=" + orgName + ", orgAddress=" + orgAddress + "]";
	}
	
}
