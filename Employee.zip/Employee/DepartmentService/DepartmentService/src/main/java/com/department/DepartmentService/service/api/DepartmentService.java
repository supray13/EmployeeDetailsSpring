package com.department.DepartmentService.service.api;

import java.util.Optional;

import org.springframework.stereotype.Service;

import com.department.DepartmentService.entity.DepartmentEntity;


@Service
public interface DepartmentService {
	
	Optional<DepartmentEntity> getDepartmentDetails(Long deptId);
	
	DepartmentEntity saveDepartment(DepartmentEntity department);

}
