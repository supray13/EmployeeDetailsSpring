package com.department.DepartmentService.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.department.DepartmentService.entity.DepartmentEntity;
import com.department.DepartmentService.service.api.DepartmentService;


@Controller
public class DepartmentController {
	
	@Autowired
	private DepartmentService departmentService;
	
	@RequestMapping(value = "/department/{deptid}", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<DepartmentEntity> getDepartmentDetails(@PathVariable(value = "deptid") Long departmentId) throws com.department.DepartmentService.exception.ResourceNotAvailableException{
		
		DepartmentEntity departmentEntity = departmentService.getDepartmentDetails(departmentId)
				.orElseThrow(() -> new com.department.DepartmentService.exception.ResourceNotAvailableException("Department not found for this id :: " + departmentId));
		
		return ResponseEntity.ok().body(departmentEntity);
	}
	
    @RequestMapping(value = "/create/department", method = RequestMethod.POST, produces = "application/json")
    public DepartmentEntity createDepartment(@RequestBody DepartmentEntity department) {
        return departmentService.saveDepartment(department);
    }

}
