package com.department.DepartmentService.service.impl;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.department.DepartmentService.dao.DepartmentDao;
import com.department.DepartmentService.entity.DepartmentEntity;
import com.department.DepartmentService.service.api.DepartmentService;

@Component
public class DepartmentServiceImpl implements DepartmentService {

	@Autowired
	private DepartmentDao departmentdao;
	
	@Override
	public Optional<DepartmentEntity> getDepartmentDetails(Long deptId) {
		
		return departmentdao.findById(deptId);
	}

	@Override
	public DepartmentEntity saveDepartment(DepartmentEntity department) {
		
		return departmentdao.save(department);
	}

}
