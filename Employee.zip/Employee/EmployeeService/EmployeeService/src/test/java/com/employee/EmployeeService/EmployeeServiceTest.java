package com.employee.EmployeeService;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.junit.Assert.assertEquals;	
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Bean;
import org.springframework.test.context.junit4.SpringRunner;

import com.employee.EmployeeService.dao.api.EmployeeDao;
import com.employee.EmployeeService.entity.EmployeeEntity;
import com.employee.EmployeeService.service.api.EmployeeService;
import com.employee.EmployeeService.service.impl.EmployeeServiceImpl;

@RunWith(SpringRunner.class)
@SpringBootTest
public class EmployeeServiceTest {
	
    @TestConfiguration
    static class EmployeeServiceTestConfiguration {
 
        @Bean
        public EmployeeService employeeService() {
            return new EmployeeServiceImpl();
        }
    }
    
    @Autowired
    private EmployeeService employeeService;

    @MockBean
    private EmployeeDao employeeDao;
    
    @Before
    public void setUp() {
        EmployeeEntity emp1 = new EmployeeEntity(1L,"Supriyo",1L);
        EmployeeEntity emp2 = new EmployeeEntity(2L,"Akshay",2L);
        EmployeeEntity emp3 = new EmployeeEntity(3L,"ken",3L);
        List<EmployeeEntity> empList = new ArrayList<>();
        empList.add(emp1);
        empList.add(emp2);
        empList.add(emp3);
        
        Optional<EmployeeEntity> empOptional = Optional.of(emp1);

        Mockito.when(employeeDao.findById(emp1.getEmpId())).thenReturn(empOptional);
        Mockito.when(employeeDao.findAll()).thenReturn(empList);
    }

    
    @Test
    public void getEmployeeDetailsTest(){
    	Optional<EmployeeEntity> empEntity = employeeService.getEmployeeDetails(1L);
    	assertEquals(empEntity.get().getEmpId(),1L);
    	
    }
    
    @Test
    public void getAllEmployeeDetailsTest(){
    	List<EmployeeEntity> empEntityList = employeeService.findAllEmployees();
    	assertEquals(empEntityList.size(),3);
    	
    }
    
    @Test
    public void saveEmployeeTest(){
    	EmployeeEntity empNew = new EmployeeEntity(1L,"Supriyo",1L);
        Mockito.when(employeeDao.save(empNew)).thenReturn(empNew);
    	EmployeeEntity empEntity = employeeService.saveEmployee(empNew);
    	assertEquals(empEntity.getEmpId(),empNew.getEmpId());
    	
    }
    
    @Test
    public void updateEmployeeTest(){
    	EmployeeEntity empOld = new EmployeeEntity(1L,"Supriyo",1L);
    	EmployeeEntity empNew = new EmployeeEntity(1L,"Suvo",1L);
    	Mockito.when(employeeDao.save(empNew)).thenReturn(empNew);
    	EmployeeEntity updatedEntity = employeeService.updateEmployee(empOld, empNew);
    	assertEquals(updatedEntity.getEmpName(),empNew.getEmpName());
    	
    }
    
}
