package com.employee.EmployeeService.model;

public class EmployeeModel {
	
	private long empId;
	
	private String empName;
	
	private String deptName;
	
	private String orgAddress;

	public EmployeeModel() {
		super();
	}

	public EmployeeModel(long empId, String empName, String deptName, String orgAddress) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.deptName = deptName;
		this.orgAddress = orgAddress;
	}

	public long getEmpId() {
		return empId;
	}

	public void setEmpId(long empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public String getDeptName() {
		return deptName;
	}

	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}

	public String getOrgAddress() {
		return orgAddress;
	}

	public void setOrgAddress(String orgAddress) {
		this.orgAddress = orgAddress;
	}

	@Override
	public String toString() {
		return "EmployeeModel [empId=" + empId + ", empName=" + empName + ", deptName=" + deptName + ", orgAddress="
				+ orgAddress + "]";
	}

}
