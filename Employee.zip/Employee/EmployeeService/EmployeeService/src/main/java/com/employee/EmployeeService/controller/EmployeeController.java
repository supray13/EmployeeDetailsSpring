package com.employee.EmployeeService.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.employee.EmployeeService.entity.DepartmentEntity;
import com.employee.EmployeeService.entity.EmployeeEntity;
import com.employee.EmployeeService.entity.OrganizationEntity;
import com.employee.EmployeeService.exception.ResourceNotAvailableException;
import com.employee.EmployeeService.model.EmployeeModel;
import com.employee.EmployeeService.service.api.EmployeeService;

@RestController
public class EmployeeController {
	
	@Autowired
	private EmployeeService employeeService;
	
	@RequestMapping(value = "/employees/all", method = RequestMethod.GET, produces = "application/json")
    public List < EmployeeEntity > getAllEmployees() {
        return employeeService.findAllEmployees();
    }
    
    @RequestMapping(value = "/create/employee", method = RequestMethod.POST, produces = "application/json")
    public EmployeeEntity createEmployee(@RequestBody EmployeeEntity employee) {
        return employeeService.saveEmployee(employee);
    }
    
    @RequestMapping(value = "/update/employee/{empid}", method = RequestMethod.PUT, produces = "application/json")
    public ResponseEntity < EmployeeEntity > updateEmployee(@PathVariable(value = "empid") long employeeId,
        @RequestBody EmployeeEntity employeeUpdatedDetails) throws ResourceNotAvailableException  {
    	
    	EmployeeEntity empEntity = employeeService.getEmployeeDetails(employeeId)
    			.orElseThrow(() -> new ResourceNotAvailableException("Employee not found for this id :: " + employeeId));
    	
    	EmployeeEntity updateEmployee = employeeService.updateEmployee(empEntity,employeeUpdatedDetails);

        return ResponseEntity.ok(updateEmployee);
    }
    
    @RequestMapping(value = "/delete/employee/{empid}", method = RequestMethod.DELETE, produces = "application/json")
    public boolean deleteEmployee(@PathVariable(value = "empid") Long employeeId) throws ResourceNotAvailableException{
		
    	EmployeeEntity empEntity = employeeService.getEmployeeDetails(employeeId)
    			.orElseThrow(() -> new ResourceNotAvailableException("Employee not found for this id :: " + employeeId));
    	
    	boolean employeeDelete = employeeService.deleteEmployee(empEntity);
    	
    	return employeeDelete;
    	
    }
    
    @RequestMapping(value = "/get/employee/{empid}", method = RequestMethod.GET, produces = "application/json")
    public ResponseEntity<EmployeeModel> getSpecificEmployee(@PathVariable(value = "empid") Long employeeId) throws ResourceNotAvailableException{
		
    	EmployeeEntity empEntity = employeeService.getEmployeeDetails(employeeId)
    			.orElseThrow(() -> new ResourceNotAvailableException("Employee not found for this id :: " + employeeId));
    	
    	DepartmentEntity deptEntity = employeeService.getDepartmentDetails(empEntity.getDeptId());
    	
    	OrganizationEntity orgEntity = employeeService.getOrganizationDetails(deptEntity.getOrgId());
    	
    	if(empEntity != null && deptEntity != null && orgEntity != null){
    	EmployeeModel empModel = new EmployeeModel();
    	empModel.setEmpId(empEntity.getEmpId());
    	empModel.setEmpName(empEntity.getEmpName());
    	empModel.setDeptName(deptEntity.getDeptName());
    	empModel.setOrgAddress(orgEntity.getOrgAddress());  	
    	
    	return ResponseEntity.ok().body(empModel);
    	} else {
    		throw new ResourceNotAvailableException("Employee details not found for Id : " + employeeId);
    	}
    	
    	
    }
    

}
