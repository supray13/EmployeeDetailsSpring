package com.employee.EmployeeService.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "DEPARTMENT")
public class DepartmentEntity implements Serializable{

	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "ID", nullable = false)
	private long deptId;
	
	@Column(name = "NAME", nullable = false)
	private String deptName;
	
	@Column(name = "ORGANIZATION_ID", nullable = false)
	private long orgId;

	public DepartmentEntity() {
		super();
	}

	public DepartmentEntity(long deptId, String deptName, long orgId) {
		super();
		this.deptId = deptId;
		this.deptName = deptName;
		this.orgId = orgId;
	}

	public long getDeptId() {
		return deptId;
	}

	public void setDeptId(long deptId) {
		this.deptId = deptId;
	}

	public String getDeptName() {
		return deptName;
	}

	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}

	public long getOrgId() {
		return orgId;
	}

	public void setOrgId(long orgId) {
		this.orgId = orgId;
	}

	@Override
	public String toString() {
		return "DepartmentEntity [deptId=" + deptId + ", deptName=" + deptName + ", orgId=" + orgId + "]";
	}	

}
