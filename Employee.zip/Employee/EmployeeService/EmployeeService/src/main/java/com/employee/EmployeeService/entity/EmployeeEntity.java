package com.employee.EmployeeService.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="EMPLOYEE")
public class EmployeeEntity implements Serializable{

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "ID", nullable = false)
	private long empId;
	
	@Column(name = "NAME", nullable = false)
	private String empName;
	
	@Column(name = "DEPARTMENT_ID", nullable = false)
	private long deptId;

	public EmployeeEntity() {
		super();
	}

	public EmployeeEntity(long empId, String empName, long deptId) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.deptId = deptId;
	}

	public long getEmpId() {
		return empId;
	}

	public void setEmpId(long empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public long getDeptId() {
		return deptId;
	}

	public void setDeptId(long deptId) {
		this.deptId = deptId;
	}

	@Override
	public String toString() {
		return "EmployeeEntity [empId=" + empId + ", empName=" + empName + ", deptId=" + deptId + "]";
	}
	
}
