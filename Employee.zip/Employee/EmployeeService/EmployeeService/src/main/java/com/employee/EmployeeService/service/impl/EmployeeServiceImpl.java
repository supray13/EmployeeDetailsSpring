package com.employee.EmployeeService.service.impl;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.employee.EmployeeService.dao.api.EmployeeDao;
import com.employee.EmployeeService.entity.DepartmentEntity;
import com.employee.EmployeeService.entity.EmployeeEntity;
import com.employee.EmployeeService.entity.OrganizationEntity;
import com.employee.EmployeeService.exception.ResourceNotAvailableException;
import com.employee.EmployeeService.service.api.EmployeeService;

@Component
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	private EmployeeDao empDao;
	
	@Autowired
	private RestTemplate restTemplate;
	
	
	@Override
	public List<EmployeeEntity> findAllEmployees() {

		return empDao.findAll();
	}


	@Override
	public EmployeeEntity saveEmployee(EmployeeEntity employee) {
		
		return empDao.save(employee);
	}


	@Override
	public Optional<EmployeeEntity> getEmployeeDetails(Long empId) {
		
		return empDao.findById(empId);
	}


	@Override
	public EmployeeEntity updateEmployee(EmployeeEntity employee,  EmployeeEntity employeeUpdatedEntity) {
		
		employee.setEmpId(employeeUpdatedEntity.getEmpId());
		employee.setEmpName(employeeUpdatedEntity.getEmpName());
		employee.setDeptId(employeeUpdatedEntity.getDeptId());
		
		final EmployeeEntity updatedEmployee = empDao.save(employee);
		return updatedEmployee;
	}


	@Override
	public boolean deleteEmployee(EmployeeEntity employee) {
		
		empDao.delete(employee);
		
		return true;
	}


	@Override
	public DepartmentEntity getDepartmentDetails(long deptId) throws ResourceNotAvailableException {
		
		HttpHeaders headers = new HttpHeaders();
	    headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
	    HttpEntity<DepartmentEntity> entity = new HttpEntity<DepartmentEntity>(headers);
	    DepartmentEntity deptEntity = null;
	    try {
		    deptEntity = restTemplate.exchange(
		         "http://localhost:8091/department/" + deptId, HttpMethod.GET, entity, DepartmentEntity.class).getBody();
		    return deptEntity;
	    } catch(Exception ex){
	    	throw new ResourceNotAvailableException("Department not found for this id :: " + deptId);
	    }
	}


	@Override
	public OrganizationEntity getOrganizationDetails(long orgId) throws ResourceNotAvailableException {
		
		HttpHeaders headers = new HttpHeaders();
	    headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
	    HttpEntity<OrganizationEntity> entity = new HttpEntity<OrganizationEntity>(headers);
	    OrganizationEntity orgEntity = null;
	    try {
	        orgEntity = restTemplate.exchange(
		         "http://localhost:8092/organization/" + orgId, HttpMethod.GET, entity, OrganizationEntity.class).getBody();
	        return orgEntity;
	    } catch(Exception ex){
	    	throw new ResourceNotAvailableException("Organization not found for this id :: " + orgId);
	    }    
	}

}