package com.employee.EmployeeService.service.api;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.employee.EmployeeService.entity.DepartmentEntity;
import com.employee.EmployeeService.entity.EmployeeEntity;
import com.employee.EmployeeService.entity.OrganizationEntity;
import com.employee.EmployeeService.exception.ResourceNotAvailableException;

@Service
public interface EmployeeService {

	List<EmployeeEntity> findAllEmployees();

	EmployeeEntity saveEmployee(EmployeeEntity employee);
	
	Optional<EmployeeEntity> getEmployeeDetails(Long empId);
	
	EmployeeEntity updateEmployee(EmployeeEntity employee, EmployeeEntity employeeUpdatedEntity);
	
	boolean deleteEmployee(EmployeeEntity employee);
	
	DepartmentEntity getDepartmentDetails(long deptId) throws ResourceNotAvailableException;
	
	OrganizationEntity getOrganizationDetails(long orgId) throws ResourceNotAvailableException;
	
	

}
